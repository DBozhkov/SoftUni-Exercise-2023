﻿using CarRacing.Models.Maps.Contracts;
using CarRacing.Models.Racers.Contracts;
using CarRacing.Utilities.Messages;
using System;
using System.Collections.Generic;
using System.Text;

namespace CarRacing.Models.Maps
{
    public class Map : IMap
    {
        public string StartRace(IRacer racerOne, IRacer racerTwo)
        {
            var firstRacer = racerOne;
            var secondRacer = racerTwo;
            string result = string.Empty;

            if (!firstRacer.IsAvailable() && !secondRacer.IsAvailable())
            {
                return OutputMessages.RaceCannotBeCompleted;
            }

            else if (!firstRacer.IsAvailable() || !secondRacer.IsAvailable())
            {
                if (!firstRacer.IsAvailable())
                {
                    return $"{secondRacer.Username} wins the race! {firstRacer.Username} was not available to race!";
                }
                else
                {
                    return $"{firstRacer.Username} wins the race! {secondRacer.Username} was not available to race!";
                }
            }

            else
            {
                var firstChanceOfWinning = 0.0;
                var secondChanceOfWinning = 0.0;
                var firstMultiplier = 0.0;
                var secondMultiplier = 0.0;

                if (firstRacer.RacingBehavior == "strict")
                {
                    firstMultiplier = 1.2;
                }
                else if (firstRacer.RacingBehavior == "aggressive")
                {
                    firstMultiplier = 1.1;
                }

                if (secondRacer.RacingBehavior == "strict")
                {
                    secondMultiplier = 1.2;
                }
                else if (secondRacer.RacingBehavior == "aggressive")
                {
                    secondMultiplier = 1.1;
                }

                firstRacer.Race();
                secondRacer.Race();

                firstChanceOfWinning = firstRacer.Car.HorsePower * firstRacer.DrivingExperience * firstMultiplier;
                secondChanceOfWinning = secondRacer.Car.HorsePower * secondRacer.DrivingExperience * secondMultiplier;

                if (firstChanceOfWinning > secondChanceOfWinning)
                {
                    result = $"{firstRacer.Username} has just raced against {secondRacer.Username}! {firstRacer.Username} is the winner!";
                }

                else
                {
                    result = $"{firstRacer.Username} has just raced against {secondRacer.Username}! {secondRacer.Username} is the winner!";
                }
            }


            return result;
        }
    }
}
