﻿using CarRacing.Models.Cars;
using CarRacing.Models.Cars.Contracts;
using CarRacing.Models.Maps;
using CarRacing.Models.Maps.Contracts;
using CarRacing.Models.Racers;
using CarRacing.Repositories;
using CarRacing.Utilities.Messages;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace CarRacing.Core.Contracts
{
    public class Controller : IController
    {
        private CarRepository cars;
        private RacerRepository racers;
        private IMap map;

        public Controller()
        {
            cars = new CarRepository();
            racers = new RacerRepository();
            map = new Map();
        }

        public string AddCar(string type, string make, string model, string VIN, int horsePower)
        {
            if (type == "SuperCar")
            {
                cars.Add(new SuperCar(make, model, VIN, horsePower));
                return $"Successfully added car {make} {model} ({VIN}).";
            }

            else if (type == "TunedCar")
            {
                cars.Add(new TunedCar(make, model, VIN, horsePower));
                return $"Successfully added car {make} {model} ({VIN}).";
            }

            throw new ArgumentException(ExceptionMessages.InvalidCarType);
        }

        public string AddRacer(string type, string username, string carVIN)
        {
            ICar car = this.cars.FindBy(carVIN);

            if (car == null)
            {
                throw new ArgumentException(ExceptionMessages.CarCannotBeFound);
            }

            if (type == "ProfessionalRacer")
            {

                this.racers.Add(new ProfessionalRacer(username, car));
                return $"Successfully added racer {username}.";
            }

            else if (type == "StreetRacer")
            {
                this.racers.Add(new StreetRacer(username, car));
                return $"Successfully added racer {username}.";
            }

            throw new ArgumentException(ExceptionMessages.InvalidRacerType);
        }

        public string BeginRace(string racerOneUsername, string racerTwoUsername)
        {
            var firstRacer = racers.FindBy(racerOneUsername);
            if (firstRacer == null)
            {
                throw new ArgumentException($"Racer {racerOneUsername} cannot be found!");
            }

            var secondRacer = racers.FindBy(racerTwoUsername);
            if (secondRacer == null)
            {
                throw new ArgumentException($"Racer {racerTwoUsername} cannot be found!");
            }

            string result = this.map.StartRace(firstRacer, secondRacer);
            return result;
        }

        public string Report()
        {
            var sb = new StringBuilder();
            foreach (var racer in racers.Models.OrderByDescending(x => x.DrivingExperience).ThenBy(x => x.Username))
            {
                sb.AppendLine(racer.ToString());
            }
            return sb.ToString().TrimEnd();
        }
    }
}
